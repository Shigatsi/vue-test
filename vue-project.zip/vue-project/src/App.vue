<template >
    <div id="nav">
    <router-link to="/">Home</router-link> |
    <router-link to="/posts">Posts</router-link>
  </div>
  <router-view></router-view>
</template>
<script>
export default {

}
</script>
<style >
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.app {
  padding: 15px;
}
</style>