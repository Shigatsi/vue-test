<template>
  <form @submit.prevent>
    <h4>Create new post</h4>
    <MyInput v-model="post.title" class="post__input" type="text" placeholder="Title" />
    <MyInput v-model="post.body" class="post__input" type="text" placeholder="About" />
    <MyButton @click="createPost">Add</MyButton>
  </form>
</template>

<script lang="ts">
import { defineComponent } from 'vue';

export default defineComponent({
  data() {
    return {
      post: {
        id: '',
        title: '',
        body: ''
      }
    }
  },
  methods: {
    createPost() {
      this.post.id = String(Date.now())
      this.$emit('create', this.post)
      this.post = {
        id: '',
        title: '',
        body: ''
      }
    }
  },
})
</script>

<style scoped>
form {
  display: flex;
  flex-direction: column;
}

.my-btn {
  align-self: flex-end;
  margin-top: 15px;
}
</style>
