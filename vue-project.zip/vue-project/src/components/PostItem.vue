<template>
  <div class="post">
    <div><strong>Id:</strong> {{ post.id }}</div>
    <div><strong>Title:</strong> {{ post.title }}</div>
    <div><strong>About:</strong> {{ post.body }}</div>
    <div class="post__btn-container">
      <MyButton @click="$emit('remove', post)">Delete</MyButton>
    </div>
  </div>
</template>

<script lang="ts">

export default {
  props: {
    post: {
      type: Object,
      required: true
    }
  },
}
</script>

<style scoped>
.post {
  display: flex;
  flex-direction: column;
  padding: 15px;
  border: 2px solid teal;
  margin-top: 15px;
  border-radius: 5px;
}

.post__btn-container {
  display: flex;
  justify-content: end;
  align-items: center;
  border-top: 0.5px solid teal;
  padding: 5px 0;
}

.post__btn {
  padding: 5px 5px;
  background: none;
  border: 1px solid teal;
  border-radius: 5px;
}
</style>
