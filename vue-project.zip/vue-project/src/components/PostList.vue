<template>
  <div v-if="posts.length > 0">
    <h3>Posts list</h3>
    <TransitionGroup name="fade">
      <PostItem v-for="post in posts" :post="post" :key="post.id" @remove="$emit('remove', post)" />
    </TransitionGroup>
  </div>
  <div v-else class="posts_type_empty">
    <h2>Post list is empty...</h2>
  </div>
</template>

<script>
import { defineComponent } from 'vue';
import PostItem from '@/components/PostItem.vue';
export default defineComponent({
  components: {
    PostItem
  },
  props: {
    posts: {
      type: Array,
      required: true
    }
  }
})
</script>

<style scoped>
/* 1. declare transition */
.fade-move,
.fade-enter-active,
.fade-leave-active {
  transition: all 0.5s cubic-bezier(0.55, 0, 0.1, 1);
}

/* 2. declare enter from and leave to state */
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
  transform: scaleX(0.01) translate(30px, 0);
}

/* 3. ensure leaving items are taken out of layout flow so that moving
      animations can be calculated correctly. */
.fade-leave-active {
  position: absolute;
}
</style>
