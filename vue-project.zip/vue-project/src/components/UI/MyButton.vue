<template>
  <button class="my-btn">
    <slot></slot>
  </button>
</template>

<script>
import { defineComponent } from 'vue'
export default defineComponent({
  name: 'MyButton'
})
</script>

<style>
.my-btn {
  padding: 5px 10px;
  background: none;
  border: 1px solid teal;
  border-radius: 5px;
}

.my-btn:hover {
  cursor: pointer;
}
</style>
