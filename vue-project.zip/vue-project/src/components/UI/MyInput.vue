<template lang="">
  <input :value="modelValue" @input="updateInput" class="inpt" type="text" />
</template>
<script>
export default {
name: 'MyInput',
props: {
    modelValue: [String, Number]
},
methods: {
    updateInput(event) {
        this.$emit('update:modelValue', event.target.value)
    }
}
}
</script>
<style >
.inpt {
    width: 100%;
    border: 1px solid teal;
    padding: 10px 15px;
    margin-top: 15px;
    border-radius: 5px;
}
</style>