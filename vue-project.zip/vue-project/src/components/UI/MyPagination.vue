<template lang="">
   <div class="pagination">
      <div 
        v-for="page in totalPages" 
        :key="page"
        class="page" 
        :class="{
          'page_type_current': page === currentPage 
        }"
        @click="updatePage"
      >
        {{ page }}
      </div>
    </div>
</template>
<script>
export default {
    name: "MyPagination",
    props: {
        totalPages: Number,
        currentPage: Number
    },
    methods: {
        updatePage(event) {
            this.$emit('changeCurrentPage', Number(event.target.innerHTML))
        }
    }
}
</script>
<style scoped>
.pagination {
    display: flex;
    margin-top: 15px;
    column-gap: 5px;
}

.page {
    border: 1px solid teal;
    padding: 10px;
}

.page:hover {
    cursor: pointer;
    opacity: 0.8;
}

.page_type_current {
    background-color: teal;
}
</style>