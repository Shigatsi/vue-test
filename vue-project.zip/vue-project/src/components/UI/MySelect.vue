<template lang="">
   <select 
    class="my-select" 
    :value="modelValue"
    @change="changeOption"
   >
    <option disabled value="">Chose...</option>
    <option 
        v-for="option in options" 
        :key="option.value" 
        :value="option.value"
    >
        {{option.name}}
    </option>
   </select>
</template>
<script>
export default {
    name: "MySelect",
    props: {
        modelValue: {
            type: String
        },
        options: {
            type: Array,
            default: () => []
        }
    },
    methods: {
        changeOption(event) {
            this.$emit('update:modelValue', event.target.value)
        }
    }
}
</script>
<style lang="">
    
</style>