export interface IPostItem {
    id: number,
    title: string,
    body: string,
  }