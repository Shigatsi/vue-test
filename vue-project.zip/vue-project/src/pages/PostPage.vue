<script lang="ts">
import axios from 'axios';
import PostForm from '@/components/PostForm.vue'
import PostList from '@/components/PostList.vue'
export default {
  components: {
    PostForm,
    PostList
  },
  data() {
    return {
      posts: [],
      dialogIsShow: false,
      isLoading: false,
      selectSort: '',
      searchQuery: '',
      currentPage: 1,
      limit: 10,
      totalPages: 0,
      sortOptions: [
        { value: 'title', name: 'sort by title' },
        { value: 'body', name: 'sort by about' },
        { value: 'id', name: 'sort by id' },

      ],
    }
  },
  methods: {
    createPost(post: any) {
      this.posts.unshift(post);
    },
    removePost(post) {
      this.posts = this.posts.filter(p => p.id !== post.id)
    },
    toggleDialog() {
      this.dialogIsShow = !this.dialogIsShow;
    },
    changePage(pageNumber) {
      this.currentPage = pageNumber;
    },
    async fetchPosts() {
      try {
        this.isLoading = true;
        const response = await axios.get("https://jsonplaceholder.typicode.com/posts",
          {
            params: {
              _page: this.currentPage,
              _limit: this.limit
            }
          });
        this.totalPages = Math.ceil(response.headers['x-total-count'] / this.limit);
        this.posts = response.data;
      } catch (e) {
        alert('Oops, smth going wrong!')
      } finally {
        this.isLoading = false;
      }
    },
    async loadMorePosts() {
      try {
        this.currentPage += 1;
        const response = await axios.get("https://jsonplaceholder.typicode.com/posts",
          {
            params: {
              _page: this.currentPage,
              _limit: this.limit
            }
          });
        this.totalPages = Math.ceil(response.headers['x-total-count'] / this.limit);
        this.posts = [...this.posts, ...response.data];
      } catch (e) {
        alert('Oops, smth going wrong!')
      } 
    }
  },
  mounted() {
    this.fetchPosts();
  
    let options = {
      rootMargin: "0px",
      threshold: 1.0,
    };
    let callback = (entries, observer) => {
      if(entries[0].isIntersecting && this.currentPage < this.totalPages) {
        this.loadMorePosts();
      }
    }

    let observer = new IntersectionObserver(callback, options);
    observer.observe(this.$refs.observer as HTMLDivElement);
  },
  computed: {
    sortedPosts() {
      return [...this.posts.sort((post1: string, post2) => String(post1[this.selectSort]).localeCompare(String(post2[this.selectSort])))]
    },
    sortedAndSearchPosts() {
      return this.sortedPosts.filter(post => post.title.toLowerCase().includes(this.searchQuery.toLocaleLowerCase()))
    }
  },
  watch: {
    // currentPage() {
    //   this.fetchPosts();
    // }
  }
}
</script>

<template>
  <div>
    <h1>Posts page</h1>
    <MyInput v-model="searchQuery" aria-placeholder="search..." />
    <div class="app__btn-container">
      <MyButton class="app__add-btn" @click="toggleDialog">Create new post</MyButton>
      <MySelect v-model="selectSort" :options="sortOptions" />
    </div>
    <MyModal v-model:show="dialogIsShow">
      <PostForm @create="createPost" />
    </MyModal>
    <PostList :posts="sortedAndSearchPosts" @remove="removePost" v-if="!isLoading" />
    <MySpinner v-else></MySpinner>
    <div ref ="observer" class="observer"></div>
    <!-- <MyPagination 
      :total-pages="totalPages" 
      :current-page = "currentPage"
      @change-current-page="changePage"
    ></MyPagination> -->
  </div>
</template>

<style>


.app__btn-container {
  display: flex;
  justify-content: space-between;
  margin: 15px 0;
}

</style>
